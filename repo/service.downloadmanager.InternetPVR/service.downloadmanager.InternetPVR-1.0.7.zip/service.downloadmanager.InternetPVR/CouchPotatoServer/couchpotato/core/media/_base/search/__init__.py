from .main import Search


def start():
    return Search()

config = []
