from .main import MovieBase


def start():
    return MovieBase()

config = []
