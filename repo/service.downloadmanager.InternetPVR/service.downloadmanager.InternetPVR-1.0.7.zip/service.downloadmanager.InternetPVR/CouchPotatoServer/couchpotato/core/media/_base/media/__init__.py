from .main import MediaPlugin


def start():
    return MediaPlugin()

config = []
