from .main import Score


def start():
    return Score()

config = []
