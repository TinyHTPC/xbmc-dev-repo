from .main import Logging


def start():
    return Logging()

config = []
