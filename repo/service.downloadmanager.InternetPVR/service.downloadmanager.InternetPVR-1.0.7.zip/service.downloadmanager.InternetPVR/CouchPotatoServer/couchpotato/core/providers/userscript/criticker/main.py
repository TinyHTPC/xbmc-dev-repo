from couchpotato.core.providers.userscript.base import UserscriptBase


class Criticker(UserscriptBase):

    includes = ['http://www.criticker.com/film/*']
