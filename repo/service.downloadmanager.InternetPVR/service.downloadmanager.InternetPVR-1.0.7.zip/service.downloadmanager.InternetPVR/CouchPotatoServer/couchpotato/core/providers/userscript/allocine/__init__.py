from .main import AlloCine


def start():
    return AlloCine()

config = []
