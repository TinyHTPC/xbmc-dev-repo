# __init__.py
#
# Copyright (C) 2010 Adrian Cristea adrian dot cristea at gmail dotcom
#
# This module is part of Axel and is released under
# the MIT License: http://www.opensource.org/licenses/mit-license.php 

