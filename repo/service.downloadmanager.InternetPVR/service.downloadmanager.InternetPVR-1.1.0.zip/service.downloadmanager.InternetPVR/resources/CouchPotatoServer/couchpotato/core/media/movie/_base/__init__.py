from .main import MovieBase


def autoload():
    return MovieBase()
