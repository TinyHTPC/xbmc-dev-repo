from .main import Library


def autoload():
    return Library()

config = []
