import xbmcgui
import xbmc
import xbmcaddon
from xbmcaddon import Addon
import os
import shutil
import time
import subprocess

__addonID__ = "os.linux.tiny"
ADDON     = Addon( __addonID__ )
ADDON_DATA  = xbmc.translatePath( "special://profile/addon_data/%s/" % __addonID__ )
ADDON_DIR = ADDON.getAddonInfo( "path" )
LangXBMC  = xbmc.getLocalizedString
ROOTDIR            = ADDON_DIR
FILES = xbmc.translatePath( ADDON_DIR + "/resources/files/" )
DEST = xbmc.translatePath( "special://home/" )
run=None
media="n"

def proptcontinue(self):
	dialog = xbmcgui.Dialog()
	if dialog.yesno("message", "do you want to leave?"):
		self.close()

class MyClass(xbmcgui.Dialog): 
  def goodbye(self):
    dialog = xbmcgui.Dialog()
    if dialog.yesno("message", "do you want to leave?"):
      self.close()

def recordingDialog(self, item, position):
	dialog = xbmcgui.Dialog()
	lines = ["Play","Delete","Back"]
	result = dialog.select(item.getLabel(), lines)
	if result == 0:
	    self.errorBox("Not implemented, yet!")
	    #xbmc.Player().play("smb://homer/vdr-video/Baltic_Storm/2008-10-17.20.58.50.99.rec/001.vdr")
	elif result == 1:
	    self.deleteRecording(position)
	elif result == 2:
	    return
	else:
	    self.errorBox("Undefined option selected!")

def HDDTOOLS():
        dialog = xbmcgui.Dialog()
	dp = xbmcgui.DialogProgress()
	promptsetup = dialog.yesno("External USB Device Setup", "This guide will install files to your USB device so it integrates ", "with XBMC with minial setup required by you.", "Would you like to continue?")
	if promptsetup:
		media="n"
		while (media == "") or (media == "n"):
			#Open External Device
			location = dialog.browse(3, 'XBMC', 'files', '', False, False, '/media/')
			device = location.replace('/media','')
			print device
			cmd = "df | grep -w "+device[1:-1]+" | awk {'print $1'}"
			print cmd
			media = subprocess.check_output(cmd, shell=True)
			print "MEDIA : " + media
			if (media == "") or (media == "n"):
				dialog.ok("ERROR", "Could not find valid USB device. Please try again", "", "[B]HINT:[/B] The path you select needs to be the root of the USB device.")
			#return
		else:
			if (media != "") or (media != "n"):
				dialog.ok("External USB Device Setup", "Could not find valid USB device. Please try again","", "[COLOR green]Brought To You By TinyHTPC[/COLOR]")
			
			print media
			wipe = dialog.select("External Device Setup",['[B]Keep my data.[/B] - (Current files will be saved.)', '[B]Format my USB.[/B] - (Fresh install, all data will be lost.)', '[B]Cancel.[/B]'])
			#if (wipe == "yes"):
			#	lines = ["Setup Device (Dont wipe any data - Your files will be saved","Format my USB - Fresh install","Cancel"]
			#	result = dialog.select("External Device Setup",['Playlist #1', 'Playlist #2', 'Playlist #3'])
			if wipe == 0:
			    #dialog.ok("TinyOS add-on Installer", "All Done","", "[COLOR yellow]Brought To You By TinyHTPC[/COLOR]")
			    dp = xbmcgui.DialogProgress()
			    dp.create("External USB Device Setup","Installing... ",'', 'Please Wait')
			    dp.update(0,"", "Checking USB...  Please Wait")
			    time.sleep(6)
			    dp.update(20,"", "Copying Files to USB...  Please Wait")
			    time.sleep(6)
			    dp.update(100,"", "Copying Files to USB...  Please Wait")
			    dialog.ok("External USB Device Setup", "All Done","", "[COLOR green]Brought To You By TinyHTPC[/COLOR]")
			elif wipe == 1:
			    dialog.yesno("WARNING!!!", "Clicking 'yes' will erase all data on your device.", "Would you like to continue?")
			elif wipe == 2:
			    return
			else:
			    return

			#elif (wipe == "no"):
			#	return
			#elif (wipe == "back"):
			#	return
			#else:
			#	dialog.ok("ERROR", "All Done","", "[COLOR red]Brought To You By TinyHTPC[/COLOR]")
			#	return
	else:
		return
	#Open External Device
	device = dialog.browse(3, 'XBMC', 'files', '', False, False, '/media/')
	if (device):
		lines = ["Setup Device (Dont wipe any data","Delete","Back"]
		result = dialog.select("External Device Setup",['Playlist #1', 'Playlist #2', 'Playlist #3'])
		if result == 0:
		    dialog.ok("TinyOS add-on Installer", "All Done","", "[COLOR yellow]Brought To You By TinyHTPC[/COLOR]")
		elif result == 1:
		    dialog.ok("TinyOS add-on Installer", "All Done","", "[COLOR red]Brought To You By TinyHTPC[/COLOR]")
		elif result == 2:
		    return
		else:
		    return
	proptcontinue
	#prompt = dialog.yesno("TinyOS External Drive Installer", "[B]Clicking yes will wipe all data on your device.[B] [C]Would you like to continue?")
	prompt = dialog.yesno("WARNING!!!", "Clicking 'yes' will erase all data on your device.", "Would you like to continue?")
	if (prompt):
		dialog = xbmcgui.Dialog()
		lines = ["Play","Delete","Back"]
		result = dialog.select("External Device Setup",['Playlist #1', 'Playlist #2', 'Playlist #3'])
		if result == 0:
		    dialog.ok("TinyOS add-on Installer", "All Done","", "[COLOR yellow]Brought To You By TinyHTPC[/COLOR]")
		elif result == 1:
		    dialog.ok("TinyOS add-on Installer", "All Done","", "[COLOR red]Brought To You By TinyHTPC[/COLOR]")
		elif result == 2:
		    return
		else:
		    return
		#choice = xbmcgui.Dialog().select("External Device Setup",["Select Device","I don't want to set up my External Device at this point in time"])
		#result = dialog.select(item.getLabel(), lines)
		#if choice == 0
			
	#Execute XBMC built-in functions
        
        
        #dp.update(0,"", "Applying settings...  Please Wait")
        #extract.all(lib,addonfolder,dp)
        #xbmc.executebuiltin('UpdateLocalAddons')
        #xbmc.executebuiltin( 'UpdateAddonRepos' )
        #dialog.ok("TinyOS add-on Installer", "All Done","", "[COLOR yellow]Brought To You By TinyHTPC[/COLOR]")


#class dialog():
#    def onStart(self):
#        #check for installed updates   
#	if run==None or len(run)<1:
#		HDDTOOLS()     

if run==None or len(run)<1:
    hddtools = HDDTOOLS()
    hddtools
    del hddtools
