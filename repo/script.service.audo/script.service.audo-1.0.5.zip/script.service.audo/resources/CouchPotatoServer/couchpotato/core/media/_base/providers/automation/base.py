from couchpotato.core.logger import CPLog
from couchpotato.core.media._base.providers.base import Provider

log = CPLog(__name__)


class AutomationBase(Provider):
    pass
